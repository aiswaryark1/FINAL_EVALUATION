import {Link} from 'react-router-dom'
function Asset(props){
    console.log(props)
    /*return(<>
    
    <div style={{border:'1px solid white',width:1000}}>
            <h4>Name     :{props.details.name}</h4>
            <h4>Email Id :{props.details.email}</h4>
            <h4>Mobile No:{props.details.mobile_no}</h4>
           
            </div> <br></br>
    
    
    </>);
}*/
return(<>
 {/*}
   <table><tr>
        <th style={{paddingLeft:30 ,width:300}}>{props.details.first_name}</th>
            <th style={{paddingLeft:30 ,width:300}}>{props.details.email}</th>
            <th style={{paddingLeft:60 ,width:300}}>{props.details.mobile_no}</th>
            <th style={{paddingRight:5}}><button style={{backgroundColor:'black',borderRadius:7,color:'white'}}>Edit</button></th>
            <th style={{paddingRight:20}}><button style={{backgroundColor:'black',borderRadius:7,color:'white'}}>Delete</button></th>

        </tr><br></br>
    </table><hr></hr>
*/}

<table style={{paddingLeft:50}}>
    <tr>
        <td style={{color:'white',width:200}}>
        <img style={{width:200,height:200}}src={props.details.url}/>
        </td>
        <td><h2>&emsp;<button style={{borderRadius:8,width:250,height:30}}><Link style={{fontSize:15,fontFamily:'Snell Roundhand, cursive',color:'black',textDecoration:'none'}} to={`/assetdetails/${props.details.am_id}`} >{props.details.am_model}</Link></button></h2></td>
    </tr>
</table>
<div >
</div><br/>


    </>);
}
export default Asset;