import {useState} from "react";
import axios from 'axios';

function AddAsset(){
    return <><Registrationform/></>
}

function Registrationform(){
    const[inputs,setInputs]=useState({})

    function handleChange(event){
        const name=event.target.name;
        const value=event.target.value;

        setInputs(values=>({...values,[name]:value}))
    }

    function handleSubmit(event){
       
       // .post('http://localhost:4000/gigs',inputs)
     
       axios
.post('http://localhost:4000/gigs',inputs,{
 headers: {
 'authorization': localStorage.getItem('mytoken'),
'Accept' : 'application/json',
 'Content-Type': 'application/json'
 }
 }
 )
        .then(response =>{
            console.log('promise fulfilled')
            console.log(response)
            alert("Asset Details added successfully")
            window.location='/assetlist';
        })
        event.preventDefault();

        console.log(inputs);
    }

    var body={
    
        textAlign:"center",
        padding:50,
        fontWeight:'bold',
        color:'black',
        fontFamily:"Times New Roman"
        
    }
    return(<>
    <form onSubmit={handleSubmit} style={body}
    ><h1> Add Asset Details</h1>
    <div style={{padding:20}}>
        <label>Type Id</label>
        <input style={{marginLeft:20}}type="text" name="am_atype_id" value={inputs.am_atype_id||""} onChange={handleChange}
        required></input>
    </div>
    <div style={{padding:20}}>
        <label>Make_Id</label>
        <input style={{marginLeft:20}} type="number" name="am_make_id" value={inputs.am_make_id||""}required onChange={handleChange}></input>
    </div>
    <div style={{padding:20}}>
        <label>Ad_Id</label>
        <input style={{marginLeft:20}} type="number"  name="am_ad_id" value={inputs.am_ad_id||""}required onChange={handleChange}></input>
    </div>
    <div style={{padding:20}}>
        <label>Model</label>
        <input style={{marginLeft:20}} type="text" name="am_model" value={inputs.am_model||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Serial Number</label>
        <input style={{marginLeft:20}} type="text" name="am_snumber" value={inputs.am_snumber||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Year</label>
        <input style={{marginLeft:20}} type="text" name="am_myyear" value={inputs.am_myyear||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Purchase Date</label>
        <input style={{marginLeft:20}} type="date" name="am_pdate" value={inputs.am_pdate||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Warranty</label>
        <input style={{marginLeft:20}} type="text" name="am_warranty" value={inputs.am_warranty||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Valid From</label>
        <input style={{marginLeft:20}} type="date" name="am_from" value={inputs.am_from||""} required onChange={handleChange}
        ></input>
    </div>
    <div style={{padding:20}}>
        <label>Valid To</label>
        <input style={{marginLeft:20}} type="date" name="am_to" value={inputs.am_to||""} required onChange={handleChange}
        ></input>
    </div>

    <div style={{padding:20}}>
        <label>Image</label>
        <input style={{marginLeft:20}} type="string" name="url" value={inputs.url||""} required onChange={handleChange}
        ></input>
    </div>
    
    <div style={{padding:20}}>
    <input style={{marginLeft:20}} type="submit" />
    <button style={{marginLeft:20}}>Cancel</button></div>
    </form>
    </>)}
export default AddAsset;