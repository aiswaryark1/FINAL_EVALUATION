import { useState,useEffect } from "react";
import axios from "axios";
import Asset from './Asset'
import {Link} from 'react-router-dom'




function AssetList(){
    if(!localStorage.getItem('mytoken')){
        window.location = '/login'
        }
    const[assets,setAssets]=useState([])
  
    useEffect(()=> {
      
        //axios.get('http://localhost:4000/gigs')
        axios.get('http://localhost:4000/gigs')
        .then(response=>{console.log('promise was fulfilled')
        console.log(response)
        setAssets(response.data)
    })
       /* console.log('The use effect hook has been executed');
        setTimeout(()=> {
            fetchStaffList();
        }, 5000) 
         style={{borderColor:'#E27D60',width:1100}}
         style={{border:'1px solid white'}}*/
        },[])
   


 

    return (<><div style={{height:1000,display:'flex',justifyContent:'center'}}>
   <div><center>
         <h2 style={{paddingLeft:40,color:'#DEF2F1',fontFamily:'copperplate'}}>ASSETS</h2><br></br></center>
      
         <ul>
              {
              assets.map(asset=>
                <li key={asset.am_id}>
                <Asset details={asset}></Asset>
                </li>)
                
                }
              </ul>
          <br></br><div style={{paddingLeft:200}}>
             <Link style={{color:"black",fontWeight:'bold'}}to={`/`}>Go back to the Home page</Link></div>
    
              </div></div></>);
    }
export default AssetList;