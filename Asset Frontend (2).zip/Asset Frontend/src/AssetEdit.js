import {useState,useEffect} from "react";
import axios from 'axios';
import {useParams} from 'react-router-dom'

function AssetEdit(){
    if(!localStorage.getItem('mytoken')){
        window.location = '/login'
        }
    const {am_id}=useParams()
    return (<>
   
    <Myform am_id={am_id}/>
    
    </>);
}

function Myform(props){
    const[inputs,setInputs]=useState({})

    useEffect(()=> {
      
        axios.get(`http://localhost:4000/gigs/${props.am_id}`)
        .then(response=>{console.log('promise was fulfilled')
        console.log(response)
        setInputs(response.data)
    })
       
    },[])


    function handleChange(event){
        const name=event.target.name;
        const value=event.target.value;

        setInputs(values=>({...values,[name]:value}))
    }

    function handleSubmit(event){
        axios
        .put(`http://localhost:4000/gigs/${props.am_id}`,inputs)
        //.put(`http://localhost:4000/gigs/${props.id}`,inputs)
        .then(response =>{
            console.log('promise fulfilled')
            console.log(response)
            alert("updated successfully")
            window.location=`/bookdetails/${props.am_id}`;
            //window.location='/stafflist';
        })
        event.preventDefault();

        console.log(inputs);
    }

var body={
    
    textAlign:"center",
    padding:50,
    fontWeight:'bold',
    color:'black',
    fontFamily:"Times New Roman"
    
}
return(<>
<form onSubmit={handleSubmit} style={body}
><h1>Asset Details</h1>
<div style={{padding:20}}>
    <label>Type Id</label>
    <input style={{marginLeft:20}}type="text" name="am_atype_id" value={inputs.am_atype_id||""} onChange={handleChange}
    required></input>
</div>
<div style={{padding:20}}>
    <label>Make_Id</label>
    <input style={{marginLeft:20}} type="number" name="am_make_id" value={inputs.am_make_id||""}required onChange={handleChange}></input>
</div>
<div style={{padding:20}}>
    <label>Ad_Id</label>
    <input style={{marginLeft:20}} type="number"  name="am_ad_id" value={inputs.am_ad_id||""}required onChange={handleChange}></input>
</div>
<div style={{padding:20}}>
    <label>Model</label>
    <input style={{marginLeft:20}} type="text" name="am_model" value={inputs.am_model||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Serial Number</label>
    <input style={{marginLeft:20}} type="text" name="am_snumber" value={inputs.am_snumber||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Year</label>
    <input style={{marginLeft:20}} type="text" name="am_myyear" value={inputs.am_myyear||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Purchase Date</label>
    <input style={{marginLeft:20}} type="date" name="am_pdate" value={inputs.am_pdate||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Warranty</label>
    <input style={{marginLeft:20}} type="text" name="am_warranty" value={inputs.am_warranty||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Valid From</label>
    <input style={{marginLeft:20}} type="date" name="am_from" value={inputs.am_from||""} required onChange={handleChange}
    ></input>
</div>
<div style={{padding:20}}>
    <label>Valid To</label>
    <input style={{marginLeft:20}} type="date" name="am_to" value={inputs.am_to||""} required onChange={handleChange}
    ></input>
</div>

<div style={{padding:20}}>
<input style={{marginLeft:20}} type="submit" />
<button style={{marginLeft:20}}>Cancel</button></div>
</form>
</>)}
export default AssetEdit;