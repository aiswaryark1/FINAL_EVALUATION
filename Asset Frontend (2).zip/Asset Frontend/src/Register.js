import { useState, useEffect } from "react";
import axios from "axios";


function Register(){
    localStorage.clear();
    return <><Form/></>
}
function Form(){
    const[inputs,setInputs]=useState({})
    //const navigate = useNavigate();
    
    function handleChange(event){
        const name=event.target.name;
        const value=event.target.value

        setInputs(values=>({...values,[name]:value}))
    }

    function handleSubmit(event){
        localStorage.clear();
        event.preventDefault();

        console.log(inputs)
   
  
    axios
    .post(`http://localhost:3002/register/`,inputs)
    .then(response => {
    //console.log('login promise was fullfilled')
    //console.log(response)
    localStorage.setItem('mytoken', response.data.access_token);
    window.location = '/assetlist'
    // local storage getter
    //console.log(localStorage.getItem('mytoken'));
    // local storage remove
    //localStorage.removeItem('mytoken');
    // local storage remove all
    //localStorage.clear();  
})

.catch(error => {
     localStorage.clear();
    //alert("got error with no data")
    if( error.response ){
    alert(error.response.data); // => the response payload 
   }
    })
    }

    var body={
        textAlign:"center",
        padding:50,
        fontWeight:'bold',
        color:"white",
        fontFamily:"Times New Roman",
        color:'black',
        height:1000
    }
    return(<>
    <form style={body} onSubmit={handleSubmit}>
<h1>Registration Form</h1>
<div style={{padding:20}}>
<label>First Name</label>
<input style={{marginLeft:20}} type='text' name="First_Name" value={inputs.First_Name||""} onChange={handleChange}></input></div>

<div style={{padding:20}}>
<label>Last Name</label>
<input style={{marginLeft:20}} type='text' name="Last_Name" value={inputs.Last_Name||""} onChange={handleChange}></input></div>

<div style={{padding:20}}>
<label>Age</label>
<input style={{marginLeft:20}} type='number' name="Age" value={inputs.Age||""} onChange={handleChange}></input></div>

<div style={{padding:20}}>
<label>Gender</label>
<select style={{marginLeft:20,width:170}} type='text' name="Gender" value={inputs.Gender||""} onChange={handleChange}>
<option style={{}}value="male">Male</option>
  <option value="female">Female</option>
    </select></div>

<div style={{padding:20}}>
<label>Address</label>
<input style={{marginLeft:20}} type='text' name="Address" value={inputs.Address||""} onChange={handleChange}></input></div>

<div style={{padding:20}}>
<label>Phone Number</label>
<input style={{marginLeft:20}} type='text' name="Phone_Number" value={inputs.Phone_Number||""} onChange={handleChange}></input></div>

<div style={{padding:20}}>
<label>Email</label>
<input style={{marginLeft:20}} type='text' name="email" value={inputs.email||""} onChange={handleChange}></input></div>
<div style={{padding:20}}><label>Password</label>
<input style={{marginLeft:20}} type='password' name="password" value={inputs.password||""} onChange={handleChange}></input></div>
<div style={{padding:20}}><label>User ID</label>
<input style={{marginLeft:20}} type='number' name="u_id" value={inputs.u_id||""} onChange={handleChange}></input></div>

<div style={{padding:20}}><label>L_ID</label>
<input style={{marginLeft:20}} type='number' name="l_id" value={inputs.l_id||""} onChange={handleChange}></input></div>


<div style={{padding:20}}><label>User Type</label>
<select style={{marginLeft:20}} type='UserType' name="UserType" value={inputs.UserType||""} onChange={handleChange}>
<option value="A">A</option>
  <option value="B">B</option>
  <option value="C">C</option>
  <option value="D">D</option></select></div>

<div><input style={{marginLeft:20}}type="submit"></input>
<button style={{marginLeft:20}}>Cancel</button></div>
    </form>
    </>)
}
export default Register;