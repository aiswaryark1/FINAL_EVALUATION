import { useState,useEffect } from "react";
import axios from "axios";
import {useParams} from 'react-router-dom'
import {Link} from 'react-router-dom'
import {useNavigate} from 'react-router-dom'
//initialze the use case to empty


/*const fetchStaffList = () =>{
    /*return fetch("http://localhost:3001/staff_list")
            .then((response) => response.json())
            .then((data)=>console.log(data));*/
           /* return axios.get("http://localhost:3001/stafflist")
            .then((response)=>console.log(response.data));
}*/


function AssetDetails(){
  if(!localStorage.getItem('mytoken')){
    window.location = '/login'
    }
    const[assets,setAssets]=useState([])
    const navigate=useNavigate()
    //const[id,setId]=useState(1)
const {am_id}=useParams()
    useEffect(()=> {
      
        axios.get(`http://localhost:4000/gigs/${am_id}`,{
          headers: {
          'authorization': localStorage.getItem('mytoken'),
          'Accept' : 'application/json',
          'Content-Type': 'application/json'
         }
          })

        .then(response=>{console.log('promise was fulfilled')
        console.log(response)
        setAssets(response.data)
    })
       /* console.log('The use effect hook has been executed');
        setTimeout(()=> {
            fetchStaffList();
        }, 5000) 
         style={{borderColor:'#E27D60',width:11*/
    },[])


    function AssetDelete(){

      if (window.confirm("Are you sure?")){
        axios
        .delete(`http://localhost:4000/gigs/${am_id}`)
       // .delete(`http://localhost:4000/gigs/${id}`)
        .then(response =>{
            console.log('promise fulfilled')
            console.log(response)
            window.location='/assetlist';  })
      }

      else{
        window.location=`/assetdetails/${am_id}`;
      }
     
    
     

     
  }
         /*console.log('The use effect hook has been executed');
          setTimeout(()=> {
              fetchStaffList();
          }, 5000) 
           style={{borderColor:'#E27D60',width:11      },[])*/
     
    return (<>
    
    <div style={{height:1000}}>
    
<table style={{paddingLeft:20}}><tr>
        <br></br>
        <td><h2 style={{color:'black',paddingLeft:300}}><img style={{width:300,height:300}}src={assets.url}/></h2></td>
        
        <td><div style={{paddingLeft:50}}>
       
      
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}> <p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>ID:&emsp;{assets.am_id}</p></div>

           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Type_ID:&emsp;{assets.am_atype_id}</p></div>

           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Make_Id:&nbsp;&emsp;{assets.am_make_id}</p></div>
        
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Ad_Id:{assets.am_ad_id}</p></div>
       
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Model name:{assets.am_model}</p></div>
        
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Serial Number:{assets.am_snumber}</p></div>
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Year:{assets.am_year}</p></div>
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Purchase Date:{assets.pdate}</p></div>
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Warranty:{assets.am_warranty}</p></div>
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Valid From:{assets.am_from}</p></div>
           <div style={{width:400,height:40,backgroundColor:'#585858',borderRadius:10}}><p style={{fontWeight:'bold', color:'white',fontFamily:'Snell Roundhand, cursive',padding:10}}>Valid To:{assets.am_to}</p></div>
      </div></td></tr>
    </table>
    
      
  
       {// <td style={{paddingRight:50}}></td>
       }

       <br/><br/>
     <div style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
       <div><button style={{backgroundColor:'black',borderRadius:9,color:'white',width:100,height:30}} type="submit" onClick={AssetDelete}>Delete</button></div>&emsp;&emsp;&emsp;
       <div><button style={{backgroundColor:'black',borderRadius:7,color:'white',width:80,height:30}} type="submit" onClick={()=>navigate(`/assetedit/${am_id}`)}>Edit</button></div>
       </div>
       <br/><br/><br/><br/><center>
      <Link style={{color:"black",fontWeight:'bold'}}to='/booklist'>Go back to the previous page</Link></center> 
       
      
    
      </div> </>);
      }
    
export default AssetDetails;