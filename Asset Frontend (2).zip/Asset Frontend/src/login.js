import { useState, useEffect } from "react";
import axios from "axios";


function Login(){
    localStorage.clear();
    return <><LoginForm/></>
}
function LoginForm(){
    const[inputs,setInputs]=useState({})
    //const navigate = useNavigate();
    
    function handleChange(event){
        const name=event.target.name;
        const value=event.target.value

        setInputs(values=>({...values,[name]:value}))
    }

    function handleSubmit(event){
        localStorage.clear();
        event.preventDefault();

        console.log(inputs)
   
  
    axios
    .post(`http://localhost:3002/login/`,inputs)
    .then(response => {
    //console.log('login promise was fullfilled')
    //console.log(response)
    localStorage.setItem('mytoken', response.data.access_token);
    window.location = '/assetlist'
    // local storage getter
    //console.log(localStorage.getItem('mytoken'));
    // local storage remove
    //localStorage.removeItem('mytoken');
    // local storage remove all
    //localStorage.clear();  
})

.catch(error => {
     localStorage.clear();
    //alert("got error with no data")
    if( error.response ){
    alert(error.response.data); // => the response payload 
   }
    })
    }

    var body={
        textAlign:"center",
        padding:50,
        fontWeight:'bold',
        color:"white",
        fontFamily:"Times New Roman",
        color:'black',
        height:1000
    }
    return(<>
    <form style={body} onSubmit={handleSubmit}>
<h1>Login Form</h1>
<div style={{padding:20}}>
<label>User Name</label>
<input style={{marginLeft:20}} type='text' name="Username" value={inputs.Username||""} onChange={handleChange}></input></div>
<div style={{padding:20}}>
<label>Email</label>
<input style={{marginLeft:20}} type='text' name="email" value={inputs.email||""} onChange={handleChange}></input></div>
<div style={{padding:20}}><label>Password</label>
<input style={{marginLeft:20}} type='password' name="password" value={inputs.password||""} onChange={handleChange}></input></div>

<div style={{padding:20}}><label>ID</label>
<input style={{marginLeft:20}} type='number' name="l_id" value={inputs.l_id||""} onChange={handleChange}></input></div>


<div style={{padding:20}}><label>User Type</label>
<input style={{marginLeft:20}} type='UserType' name="UserType" value={inputs.UserType||""} onChange={handleChange}></input></div>

<div><input style={{marginLeft:20}}type="submit"></input>
<button style={{marginLeft:20}}>Cancel</button></div>
    </form>
    </>)
}
export default Login;