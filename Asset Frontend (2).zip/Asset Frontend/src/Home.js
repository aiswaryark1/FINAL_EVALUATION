

function Home(){
    var body={
    
        textAlign:"center",
      
        padding:20,
       
        color:'black',
        fontFamily:'cursive'
        
    }
    return(<>
    


    <div style={body}> 
    <img style={{width:1400,height:400}}src="https://images.pexels.com/photos/705164/computer-laptop-work-place-camera-705164.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"/>
       
       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat eget lorem quis hendrerit. Donec ut tortor justo. Ut malesuada vel lorem et volutpat. Nunc scelerisque sapien eu venenatis iaculis. Proin turpis nisl, gravida in elit sed, tempus vulputate eros. Maecenas arcu orci, auctor quis viverra vitae, rutrum ut quam. Mauris et magna tempor, suscipit diam vel, dapibus leo.</p>
       <p>Aliquam in commodo urna. Aliquam euismod, arcu eget fermentum ultrices, felis tortor lacinia nisi, sit amet ultrices lacus ex vitae mauris. Suspendisse ullamcorper venenatis commodo. Ut iaculis imperdiet mi nec condimentum. Curabitur sed lacinia tellus, at varius mi. Nam bibendum egestas nulla sed consectetur. Curabitur finibus leo et lobortis lacinia. Nunc est ligula, vulputate eu lorem et, imperdiet egestas nisl. Vestibulum posuere finibus lacus. Aliquam erat volutpat.</p>
        </div>
    </>)
}
export default Home;