import { BrowserRouter as Router,Routes,Route,Link } from "react-router-dom";
import Home from './Home.js'
import About from './About.js'
import Nomatch from './Nomatch.js'
import AssetList from './AssetList.js'
import AssetDetails from './AssetDetails.js'
import AssetEdit from "./AssetEdit.js";
//import Asset from "./Asset.js";
import Login from "./login.js";
import background from './background.jpg'
import AddAsset from "./AddAsset.js";
import Register from "./Register.js";

function App(){
    var menubar={
        
        display:'inline',
        justifyContent:'space-between',
        width:10,
        height:50,
       
        listStyle:'none'
        
        }
    var main=
    {
    
   
               
    display:'flex',
    justifyContent:'space-between',
    //backgroundColor:'#28282B'
    backgroundColor:'#388087'
    //backgroundImage:`url(${background})`
   
  
    }
  
//backgroundImage:`url(${background})`backgroundColor:'#17252A',  backgroundColor:'#3AAFA9' backgroundColor:'#2B7A7B'

   
    return( <div style={{backgroundImage:`url(${background})`}}  >
    {/*style={{backgroundColor:'#BADFE7'}}*/
    }
  
         
       
         <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <Router>
        <div style={main}>
      
            <h1 style={{fontFamily:'copperplate',color:'WHITE',fontWeight:'bold',backgroundColor:'#388087'}}>ASSETS MANAGEMENT SYSTEM</h1>
            
          

       <div style={{backgroundColor:'black',paddingTop:30}}>
       <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <center><ul  style={menubar}>
        <li  style={{display:'inline',padding:30}}><Link style={{color:'white',fontFamily:'Brush Script MT',textDecoration:'none'}} activeStyle={{color:'red'}} to="/">Home</Link></li>
        <li  style={{display:'inline',padding:30}}><Link style={{color:'white',textDecoration:'none'}}to="/about">About</Link></li>
        {localStorage.getItem('mytoken') &&<li  style={{display:'inline',padding:30}}><Link style={{color:'white',textDecoration:'none'}}to="/addasset">Add New Asset</Link></li>}
        {!localStorage.getItem('mytoken') &&<li  style={{display:'inline',padding:30}}><Link style={{color:'white',textDecoration:'none'}}to="/login">LogIn</Link></li>}
        {!localStorage.getItem('mytoken') &&<li  style={{display:'inline',padding:30}}><Link style={{color:'white',textDecoration:'none'}}to="/register">Register</Link></li>}
        {localStorage.getItem('mytoken') &&<li style={{display:"inline",padding:30}}><Link style={{color:'white',textDecoration:'none'}}  onClick={()=>{window.location ='/login'}} to="/login">Logout</Link></li>}
        {localStorage.getItem('mytoken') && <li  style={{display:'inline',padding:30}}><Link style={{color:'white',textDecoration:'none'}}to="/assetlist" activeStyle={{color: 'red'}} >View Assets</Link></li>}

        </ul></center>  </div>
</div>
        <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path="/about" element={<About/>}></Route>
           <Route path="/login" element ={<Login/>}></Route>
           <Route path="/register" element={<Register/>}></Route>

            <Route path="/addasset" element={<AddAsset/>}></Route>
            
            <Route path="*" element={<Nomatch/>}></Route>
            <Route path="/assetlist" element={<AssetList/>}></Route>
            <Route path="/assetdetails/:am_id" element={<AssetDetails/>}></Route>
            <Route path="/assetedit/:am_id" element={<AssetEdit/>}></Route>
            </Routes>
        
    <br></br>
    <footer style={{height:0,paddingBottom:10,color:'white',fontStyle:'Lucida Handwriting',paddingBottom:50}}>
  <p style={{padding:10}}><b><center>copyright@2021</center></b></p>
    </footer>
   

   
    </Router>
    </div>)
}
export default App;
