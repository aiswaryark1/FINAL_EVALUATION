
const Gig =  require('../models/Gig');
const Staff=require('./staff.json')
var gigDao={
    findAll:findAll,
    create:create,
    findByam_id:findByam_id,
    deleteByam_id:deleteByam_id,
    updateGig:updateGig
}
 function findAll(){
     return Gig.findAll();
 }

 function findByam_id(am_id){
     return Gig.findByPk(am_id);
 }

 function deleteByam_id(am_id){
     return Gig.destroy({where:{am_id:am_id}});
 }

 function create(gig){
     var newGig = new Gig(gig);
    
     return newGig.save();
     
 }

 function updateGig(gig,am_id){
     var updateGig={
         am_id:gig.am_id,
         am_atype_id:gig.am_atype_id,
         am_make_id:gig.am_make_id,
         am_ad_id:gig.am_ad_id,
         am_model:gig.am_model,
         am_snumber:gig.am_snumber,
         am_myyear:gig.am_myyear,
         am_pdate:gig.am_pdate,
         am_warranty:gig.am_warranty,
         am_from:gig.am_from,
         am_to:gig.am_to,
        url:gig.url

        
     };
     return Gig.update(updateGig,{where:{am_id:am_id}});
 }
 module.exports=gigDao;