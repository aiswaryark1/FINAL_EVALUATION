const express = require('express');
const router = express.Router();
const gigController=require('../controller/gig.controller');

router.post('/',gigController.addGig);
router.get('/',gigController.findGigs);
router.get('/:am_id',gigController.findGigByam_id);
router.put('/:am_id',gigController.updateGig);
router.delete('/:am_id',gigController.deleteByam_id);

module.exports = router;

