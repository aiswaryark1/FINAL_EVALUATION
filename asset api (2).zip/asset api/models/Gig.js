const Sequelize = require('sequelize');
const db=require('../config/database');

const Gig=db.define('gig',{
    am_id:{
        type:Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    am_atype_id:{
        type:Sequelize.STRING,
        allowNull:false
    },
    am_make_id:{
        type:Sequelize.INTEGER,
        allowNull:false
    },
    am_ad_id:{
        type:Sequelize.INTEGER,
        allowNull:false
    },
    am_model:{
        type:Sequelize.STRING,
        
    },
    am_snumber:{
        type:Sequelize.STRING,
        
    },
    am_myyear:{
        type:Sequelize.STRING,
        
    },
    am_pdate:{
        type:Sequelize.DATEONLY},
    am_warranty:{
        type:Sequelize.STRING
        
    },
    am_from:{
        type:Sequelize.DATEONLY},

    am_to:{
        type:Sequelize.DATEONLY},
    url:{
        type:Sequelize.STRING
    }

    
        
});

module.exports=Gig;