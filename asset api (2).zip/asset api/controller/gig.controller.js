

const gigDao = require('../dao/gig.dao');

var gigController={
    addGig:addGig,
    findGigs:findGigs,
    findGigByam_id:findGigByam_id,
    updateGig:updateGig,
    deleteByam_id:deleteByam_id

}
 function addGig(req,res){
     let gig = req.body;
     gigDao.create(gig).
     then((data) => {
       
         res.send(data);
     })
     .catch((error)=>{
         console.log(error);
     });
 }

 function findGigByam_id(req,res){
     gigDao.findByam_id(req.params.am_id).
     then((data) => {

         res.send(data);
     })
     .catch((error) =>{
         console.log(error);
     });
 }

 function deleteByam_id(req,res){
     gigDao.deleteByam_id(req.params.am_id).
     then((data) =>{
         res.status(200).json({
             message:"Gig deleted successfully",
             gig:data
         })
     })
     .catch((error) =>{
         console.log(error);
     });
 }

 function updateGig(req,res){
     gigDao.updateGig(req.body,req.params.am_id).
     then((data) =>{
         res.status(200).json({
             message:"Gig updated successfully",
             gig:data
         })
     })
     .catch((error)=>{
         console.log(error)
     });
 }
 function findGigs(req,res){
     gigDao.findAll().
     then((data)=>{
         res.send(data)
     })
     .catch((error) =>{
         console.log(error)
     });

     }
 module.exports = gigController;
